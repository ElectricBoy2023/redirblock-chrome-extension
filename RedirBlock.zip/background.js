let adLinks = [];

// Load adlinks.txt
fetch(chrome.runtime.getURL('adlinks.txt'))
  .then(res => res.text())
  .then(text => {
    adLinks = text.split(/\r?\n/).filter(Boolean);
  });

// Intercept requests
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    return new Promise((resolve) => {
      chrome.storage.local.get(['enabled'], (res) => {
        const enabled = res.enabled ?? true;
        if (!enabled) return resolve({}); // do nothing if OFF

        const url = details.url;
        for (const domain of adLinks) {
          if (url.includes(domain)) {
            return resolve({ redirectUrl: 'about:blank' });
          }
        }
        resolve({});
      });
    });
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
