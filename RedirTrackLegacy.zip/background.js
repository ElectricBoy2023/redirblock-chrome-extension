let adLinks = [];

// Load adlinks.txt
fetch(chrome.runtime.getURL('adlinks.txt'))
  .then(res => res.text())
  .then(text => {
    adLinks = text.split(/\r?\n/).filter(Boolean);
  });

// Intercept requests
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    const enabled = (localStorage.getItem('enabled') ?? 'true') === 'true';
    if (!enabled) return {};

    const url = details.url;
    for (const domain of adLinks) {
      if (url.includes(domain)) {
        return { redirectUrl: 'about:blank' };
      }
    }
    return {};
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
