const toggleBtn = document.getElementById('toggleBtn');

// Load state from storage
chrome.storage.local.get(['enabled'], (res) => {
  const enabled = res.enabled ?? true; // default ON
  toggleBtn.textContent = enabled ? 'ON' : 'OFF';
});

// Toggle state
toggleBtn.addEventListener('click', () => {
  chrome.storage.local.get(['enabled'], (res) => {
    const newState = !(res.enabled ?? true);
    chrome.storage.local.set({ enabled: newState });
    toggleBtn.textContent = newState ? 'ON' : 'OFF';
  });
});
